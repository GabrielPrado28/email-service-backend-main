import { resolve } from 'path';

import './database';

import express from 'express';

import userRoutes from './routes/userRoutes';
import emailRoutes from './routes/emailRoutes';


class App {
  constructor() {
    this.app = express();
    this.middlewares();
    this.routes();
  }

  middlewares() {
    this.app.use(express.urlencoded({ extended: true }));
    this.app.use(express.json());
    this.app.use('/images/', express.static(resolve(__dirname, '..', 'uploads', 'images')));
  }

  routes() {   
    this.app.use('/emails/', emailRoutes);
    this.app.use('/users/', userRoutes);
  }
}

export default new App().app;
